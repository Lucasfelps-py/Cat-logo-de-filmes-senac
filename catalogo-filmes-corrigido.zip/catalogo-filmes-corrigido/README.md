# Catálogo de Filmes — UC32

Aplicação CRUD feita com Python, Flask, SQLite, HTML e Jinja2.

## Funcionalidades
- Cadastrar filmes com título, gênero, ano e nota de 1 a 10.
- Listar filmes cadastrados.
- Editar informações.
- Excluir filmes.
- Criar o banco SQLite automaticamente ao iniciar.

## Executar no Windows
Abra o terminal nesta pasta e execute:

```powershell
python -m venv .venv
python -m pip install -r requirements.txt
python app.py
```

Acesse http://127.0.0.1:5000 no navegador.

## Publicar no GitHub
Crie um repositório vazio no GitHub. No terminal da pasta do projeto:

```bash
git init
git add .
git commit -m "Cria catálogo de filmes com Flask e SQLite"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/catalogo-filmes.git
git push -u origin main
```

Troque a URL de exemplo pela URL real do seu repositório.

## Deploy no Render
- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn app:app`

Conecte o repositório do GitHub no Render e crie um Web Service.

## Banco de dados
O SQLite pode perder os dados quando o ambiente hospedado for recriado ou reiniciado sem armazenamento persistente. Isso é esperado para esta atividade de estudo.
