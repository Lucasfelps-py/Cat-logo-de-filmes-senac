import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, abort

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "chave-local-catalogo-filmes")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.environ.get("DATABASE_PATH", os.path.join(BASE_DIR, "filmes.db"))


def conectar_banco():
    """Abre uma conexão com o banco SQLite."""
    conexao = sqlite3.connect(DATABASE)
    conexao.row_factory = sqlite3.Row
    return conexao


def criar_banco():
    """Cria a tabela de filmes automaticamente."""
    with conectar_banco() as conexao:
        conexao.execute("""
            CREATE TABLE IF NOT EXISTS filmes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                genero TEXT NOT NULL,
                ano INTEGER NOT NULL,
                nota REAL NOT NULL CHECK (nota >= 1 AND nota <= 10)
            )
        """)


def validar_filme(formulario):
    """Valida os dados enviados pelo formulário."""
    titulo = formulario.get("titulo", "").strip()
    genero = formulario.get("genero", "").strip()
    ano_texto = formulario.get("ano", "").strip()
    nota_texto = formulario.get("nota", "").strip()

    if not titulo or not genero or not ano_texto or not nota_texto:
        raise ValueError("Preencha todos os campos.")

    try:
        ano = int(ano_texto)
        nota = float(nota_texto.replace(",", "."))
    except ValueError:
        raise ValueError("Informe um ano e uma nota válidos.")

    if not 1888 <= ano <= 2100:
        raise ValueError("O ano deve estar entre 1888 e 2100.")
    if not 1 <= nota <= 10:
        raise ValueError("A nota deve estar entre 1 e 10.")

    return titulo, genero, ano, nota


@app.route("/")
def index():
    """READ: lista os filmes cadastrados."""
    with conectar_banco() as conexao:
        filmes = conexao.execute(
            "SELECT * FROM filmes ORDER BY titulo COLLATE NOCASE"
        ).fetchall()
    return render_template("index.html", filmes=filmes)


@app.route("/novo", methods=["GET", "POST"])
def novo_filme():
    """CREATE: cadastra um filme."""
    if request.method == "POST":
        try:
            titulo, genero, ano, nota = validar_filme(request.form)
            with conectar_banco() as conexao:
                conexao.execute(
                    "INSERT INTO filmes (titulo, genero, ano, nota) VALUES (?, ?, ?, ?)",
                    (titulo, genero, ano, nota),
                )
            flash("Filme cadastrado com sucesso!", "sucesso")
            return redirect(url_for("index"))
        except ValueError as erro:
            flash(str(erro), "erro")
            return render_template("form.html", filme=None, valores=request.form), 400

    return render_template("form.html", filme=None, valores={})


@app.route("/editar/<int:filme_id>", methods=["GET", "POST"])
def editar_filme(filme_id):
    """UPDATE: altera os dados de um filme."""
    with conectar_banco() as conexao:
        filme = conexao.execute(
            "SELECT * FROM filmes WHERE id = ?", (filme_id,)
        ).fetchone()

    if filme is None:
        abort(404)

    if request.method == "POST":
        try:
            titulo, genero, ano, nota = validar_filme(request.form)
            with conectar_banco() as conexao:
                conexao.execute(
                    """UPDATE filmes
                       SET titulo = ?, genero = ?, ano = ?, nota = ?
                       WHERE id = ?""",
                    (titulo, genero, ano, nota, filme_id),
                )
            flash("Filme atualizado com sucesso!", "sucesso")
            return redirect(url_for("index"))
        except ValueError as erro:
            flash(str(erro), "erro")
            return render_template("form.html", filme=filme, valores=request.form), 400

    return render_template("form.html", filme=filme, valores=dict(filme))


@app.route("/excluir/<int:filme_id>", methods=["POST"])
def excluir_filme(filme_id):
    """DELETE: exclui um filme."""
    with conectar_banco() as conexao:
        resultado = conexao.execute(
            "DELETE FROM filmes WHERE id = ?", (filme_id,)
        )
        if resultado.rowcount == 0:
            abort(404)

    flash("Filme excluído com sucesso!", "sucesso")
    return redirect(url_for("index"))


@app.errorhandler(404)
def pagina_nao_encontrada(erro):
    return render_template("404.html"), 404


# Cria o banco e a tabela ao iniciar a aplicação.
criar_banco()

if __name__ == "__main__":
    app.run(debug=True)
